package com.CrimeAnalysisAndReportingSystem.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.CrimeAnalysisAndReportingSystem.entity.Evidence;
import com.CrimeAnalysisAndReportingSystem.entity.Incidents;
import com.CrimeAnalysisAndReportingSystem.entity.Suspects;
import com.CrimeAnalysisAndReportingSystem.entity.Victims;
import com.CrimeAnalysisAndReportingSystem.exception.EvidenceNotFoundException;
import com.CrimeAnalysisAndReportingSystem.service.CrimeAnalysisServiceImpl;
import com.CrimeAnalysisAndReportingSystem.service.ICrimeAnalysisService;
import com.CrimeAnalysisAndReportingSystem.util.DBUtil;


public class EvidenceDAOImpl implements IEvidenceDAO {
	private static Connection connEvidence;

	@Override
	public int addEvidence(Evidence evidence) throws ClassNotFoundException, SQLException {
		connEvidence = DBUtil.createConnection();
		String query = "INSERT INTO Evidence(Description, LocationFound, IncidentID) VALUES(?,?,?)";

		PreparedStatement prepareStEvidence = connEvidence.prepareStatement(query);
		prepareStEvidence.setString(1, evidence.getDescription());
		prepareStEvidence.setString(2, evidence.getLocation());
		prepareStEvidence.setInt(3, evidence.getIncident().getIncidentID());

		int result = prepareStEvidence.executeUpdate();

		DBUtil.closeConnection();
		return result;
	}

	@Override
	public int updateEvidence(Evidence evidence)
			throws ClassNotFoundException, SQLException, EvidenceNotFoundException {
		connEvidence = DBUtil.createConnection();
		String query = "UPDATE Evidence SET Description=?, LocationFound=?, IncidentID=? " + "WHERE EvidenceID=?";

		PreparedStatement prepareStEvidence = connEvidence.prepareStatement(query);
		prepareStEvidence.setString(1, evidence.getDescription());
		prepareStEvidence.setString(2, evidence.getLocation());
		prepareStEvidence.setInt(3, evidence.getIncident().getIncidentID());
		prepareStEvidence.setInt(4, evidence.getEvidenceId());

		int result = prepareStEvidence.executeUpdate();

		DBUtil.closeConnection();
		return result;
	}

	@Override
	public int deleteEvidence(int evidenceID) throws ClassNotFoundException, SQLException, EvidenceNotFoundException {
		Evidence evidence = null;

		connEvidence = DBUtil.createConnection();

		String queryCheck = "SELECT * FROM Evidence WHERE EvidenceID = ?";
		String queryDelete = "DELETE FROM Evidence WHERE EvidenceID = ?";

		String locationFound = null;
		String description = null;

		int success = 0;

		PreparedStatement prepareStEvidence = connEvidence.prepareStatement(queryCheck);
		PreparedStatement prepareStDelete = connEvidence.prepareStatement(queryDelete);

		prepareStEvidence.setInt(1, evidenceID);
		prepareStDelete.setInt(1, evidenceID);

		ResultSet rsEvidence = prepareStEvidence.executeQuery();

		while (rsEvidence.next()) {// Till there are further records.
			evidenceID = rsEvidence.getInt("EvidenceID");
			description = rsEvidence.getString("Description");
			locationFound = rsEvidence.getString("LocationFound");

			evidence = new Evidence(description, locationFound);
		}

		if (evidence == null) {
			throw new EvidenceNotFoundException("No Evidence Found");
		} else {
			success = prepareStDelete.executeUpdate();
		}
		DBUtil.closeConnection();
		return success;
	}

	@Override
	public Evidence viewEvidence(int evidenceID)
			throws ClassNotFoundException, SQLException, EvidenceNotFoundException {
		Evidence evidence = null;
		Incidents incident = null;

		int incidentID = 0;
		String incidentType = null;
		LocalDate incDate = null;
		String location = null;
		String iDescription = null;
		String status = null;
		
		String locationFound = null;
		String description = null;
		
		Victims victim = null;
		Suspects suspect = null;
		
		int victimID = 0;
		String vFirstName = null;
		String vLastName = null;
		LocalDate vDateOfBirth = null;
		String vGender = null;
		String vContactInfo = null;
		
		int suspectID = 0;
		String sFirstName = null;
		String sLastName = null;
		LocalDate sDateOfBirth = null;
		String sGender = null;
		String sContactInfo = null;
		
		connEvidence = DBUtil.createConnection();

		String queryCheck = "SELECT e.EvidenceID, e.Description, e.LocationFound," 
				+ " i.IncidentID,i.IncidentType,i.IncidentDate,i.Location,i.Description,i.Status," 
				+ " v.VictimID,v.FirstName,v.LastName,v.DateOfBirth,v.Gender,v.ContactInformation," 
				+ " s.SuspectID,s.FirstName,s.LastName,s.DateOfBirth,s.Gender,s.ContactInformation " 
				+ " FROM Evidence e JOIN Incidents i "
				+ "ON e.IncidentID = i.IncidentID JOIN Victims v " 
				+ "ON i.VictimId = v.VictimID JOIN Suspects s ON i.SuspectID = s.SuspectID " 
				+ "WHERE e.EvidenceID = ?";
		
				
		PreparedStatement prepareStEvidence = connEvidence.prepareStatement(queryCheck);
		prepareStEvidence.setInt(1, evidenceID);
		
		ResultSet rsEvidence = prepareStEvidence.executeQuery();

		while (rsEvidence.next()) {// Till there are further records.
			incidentID = rsEvidence.getInt("i.IncidentID");
			incidentType = rsEvidence.getString("i.IncidentType");
			incDate = rsEvidence.getDate("i.IncidentDate").toLocalDate();
			location =rsEvidence.getString("i.Location");
			iDescription = rsEvidence.getString("i.Description");
			status = rsEvidence.getString("i.Status");
			
			evidenceID = rsEvidence.getInt("e.EvidenceID");
			description = rsEvidence.getString("e.Description");
			locationFound = rsEvidence.getString("e.LocationFound");
			
			victimID = rsEvidence.getInt("v.VictimID");
			vFirstName = rsEvidence.getString("v.FirstName");
			vLastName = rsEvidence.getString("v.LastName");
			vDateOfBirth = rsEvidence.getDate("v.DateOfBirth").toLocalDate();
			vGender = rsEvidence.getString("v.Gender");
			vContactInfo = rsEvidence.getString("v.ContactInformation");
			
			suspectID = rsEvidence.getInt("s.SuspectID");
			sFirstName = rsEvidence.getString("s.FirstName");
			sLastName = rsEvidence.getString("s.LastName");
			sDateOfBirth = rsEvidence.getDate("s.DateOfBirth").toLocalDate();
			sGender = rsEvidence.getString("s.Gender");
			sContactInfo = rsEvidence.getString("s.ContactInformation");
			
			victim = new Victims(victimID, vFirstName, vLastName, vDateOfBirth, vGender, vContactInfo);
			
			suspect = new Suspects(suspectID, sFirstName, sLastName, sDateOfBirth, sGender, sContactInfo);
		
			incident = new Incidents(incidentID, incidentType, incDate, location, iDescription, status, victim, suspect);
			
			evidence = new Evidence(evidenceID, description, locationFound, incident);
		}
		DBUtil.closeConnection();

		if (evidence == null) {
			throw new EvidenceNotFoundException("No Evidence Found");
		}

		return evidence;
		}

	@Override
	public List<Evidence> viewEvidences() throws ClassNotFoundException, SQLException, EvidenceNotFoundException {
		ICrimeAnalysisService incidentService = new CrimeAnalysisServiceImpl();

		List<Evidence> evidences = new ArrayList<>();
		Incidents incident = null;

		String locationFound = null;
		String description = null;

		Evidence evidence = null;

		connEvidence = DBUtil.createConnection();

		String query = "SELECT * FROM Evidence";

		int incidentID = 0;
		int evidenceID = 0;

		PreparedStatement prepareStEvidence = connEvidence.prepareStatement(query);

		ResultSet rsEvidence = prepareStEvidence.executeQuery();

		while (rsEvidence.next()) {// Till there are further records.
			incidentID = rsEvidence.getInt("IncidentID");
			evidenceID = rsEvidence.getInt("EvidenceID");
			description = rsEvidence.getString("Description");
			locationFound = rsEvidence.getString("LocationFound");
			incident = incidentService.viewIncident(incidentID);

			evidence = new Evidence(evidenceID, description, locationFound, incident);
			evidences.add(evidence);
		}
		DBUtil.closeConnection();

		if (evidences.size() == 0) {
			throw new EvidenceNotFoundException("No evidence Found");
		}

		return evidences;
	}

}
