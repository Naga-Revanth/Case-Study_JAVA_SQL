package com.CrimeAnalysisAndReportingSystem.dao;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.CrimeAnalysisAndReportingSystem.entity.Evidence;
import com.CrimeAnalysisAndReportingSystem.entity.Incidents;
import com.CrimeAnalysisAndReportingSystem.exception.EvidenceNotFoundException;


public class EvidenceDAOImplTest {
	private IEvidenceDAO evidenceDAO;
	
	@Before
	public void setUp() throws Exception {
		evidenceDAO = new EvidenceDAOImpl();
	}

	@After
	public void tearDown() throws Exception {
		evidenceDAO = null;
	}

	@Test
	public final void testAddEvidence() {
		int result = 0;
		Incidents incident = new Incidents();
		int IncidentID = 10;
		incident.setIncidentID(IncidentID);
		Evidence evidence = new Evidence(10, "Knife", "Kitchen", incident);
		try {
			result = evidenceDAO.addEvidence(evidence);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		}
		assertTrue(result == 1);
	}

	@Test
	public final void testUpdateEvidence() {
		int result = 0;
		Incidents incident = new Incidents();
		int IncidentID = 2;
		incident.setIncidentID(IncidentID);
		Evidence evidence = new Evidence(2, "Knife", "Kitchen", incident);
		try {
			result = evidenceDAO.updateEvidence(evidence);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		}catch(SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		}catch(EvidenceNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}
		assertTrue(result == 1);
	}

	@Test
	public final void testDeleteEvidence() {
		int result = 0;
		int evidenceID = 3;
		try {
			result = evidenceDAO.deleteEvidence(evidenceID);
			}catch (ClassNotFoundException cnfe) {
				System.out.println("Looks like JDBC driver is NOT loaded.");
			}catch(SQLException se) {
				System.out.println("Either url, username or password is wrong or duplicate record");
				se.printStackTrace();
			}catch(EvidenceNotFoundException cnfe) {
				System.out.println(cnfe.getMessage());
			}
		
		assertTrue(result == 1);
	}

	@Test
	public final void testViewEvidence() {
		Evidence evidence = null;
		int evidenceID = 1;

		try {
			evidence = evidenceDAO.viewEvidence(evidenceID);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (EvidenceNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}

		assertTrue(evidence != null);
	}

	@Test
	public final void testViewEvidences() {
		List<Evidence> evidenceList = null;

		try {
			evidenceList = evidenceDAO.viewEvidences();
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (EvidenceNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}
		assertTrue(evidenceList != null);
	}

}
