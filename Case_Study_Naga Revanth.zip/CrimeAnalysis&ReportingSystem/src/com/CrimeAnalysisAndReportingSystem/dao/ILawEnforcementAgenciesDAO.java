package com.CrimeAnalysisAndReportingSystem.dao;

import java.sql.SQLException;
import java.util.List;

import com.CrimeAnalysisAndReportingSystem.entity.lawEnforcementAgencies;
import com.CrimeAnalysisAndReportingSystem.exception.AgencyNotFoundException;

public interface ILawEnforcementAgenciesDAO {
	public int addLawEnforcementAgency(lawEnforcementAgencies lea) throws ClassNotFoundException, SQLException;
	public int updateLawEnforcementAgency(lawEnforcementAgencies lea) throws ClassNotFoundException, SQLException, AgencyNotFoundException;
	public int deleteLawEnforcementAgency(int agencyID) throws ClassNotFoundException, SQLException, AgencyNotFoundException;
	public lawEnforcementAgencies viewLawEnforcementAgency(int agencyID) throws ClassNotFoundException, SQLException, AgencyNotFoundException;
	public List<lawEnforcementAgencies>viewLawEnforcementAgencies() throws ClassNotFoundException, SQLException, AgencyNotFoundException;


}
