package com.CrimeAnalysisAndReportingSystem.dao;

import java.sql.SQLException;
import java.util.List;
import com.CrimeAnalysisAndReportingSystem.entity.Victims;
import com.CrimeAnalysisAndReportingSystem.exception.VictimNotFoundException;


public interface IVictimDAO {
	public int addVictim(Victims victim) throws ClassNotFoundException, SQLException;

	public int updateVictim(Victims victim) throws ClassNotFoundException, SQLException, VictimNotFoundException;

	public int deleteVictim(int victimId) throws ClassNotFoundException, SQLException, VictimNotFoundException;

	public Victims viewVictim(int victimId) throws ClassNotFoundException, SQLException, VictimNotFoundException;

	public List<Victims> viewVictims() throws ClassNotFoundException, SQLException, VictimNotFoundException;
}
