package com.CrimeAnalysisAndReportingSystem.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.CrimeAnalysisAndReportingSystem.entity.lawEnforcementAgencies;
import com.CrimeAnalysisAndReportingSystem.exception.AgencyNotFoundException;
import com.CrimeAnalysisAndReportingSystem.util.DBUtil;


public class LawEnforcementAgenciesDAOImpl implements ILawEnforcementAgenciesDAO {
private static Connection connLea;
	
	@Override
	public int addLawEnforcementAgency(lawEnforcementAgencies lea) throws ClassNotFoundException, SQLException {
		connLea = DBUtil.createConnection();
		String query = "INSERT INTO lawenforcementagencies(AgencyName, Jurisdiction, ContactInformation, Officers) " + "VALUES(?,?,?,?)";

		
		PreparedStatement prepareStLea = connLea.prepareStatement(query);
		prepareStLea.setString(1, lea.getAgencyName());
		prepareStLea.setString(2, lea.getJurisdiction());
		prepareStLea.setString(3, lea.getPhoneNumber());

		int result = prepareStLea.executeUpdate();

		DBUtil.closeConnection();
		return result;
	}

	@Override
	public int updateLawEnforcementAgency(lawEnforcementAgencies lea)
			throws ClassNotFoundException, SQLException, AgencyNotFoundException {
		connLea = DBUtil.createConnection();
		String query = "UPDATE lawenforcementagencies SET AgencyName=?, Jurisdiction=?, ContactInformation=? "
				+ "WHERE AgencyID=?";
		
		PreparedStatement prepareStLea = connLea.prepareStatement(query);
		prepareStLea.setString(1, lea.getAgencyName());
		prepareStLea.setString(2, lea.getJurisdiction());
		prepareStLea.setString(3, lea.getPhoneNumber());
		prepareStLea.setInt(4, lea.getAgencyId());
		
		int result = prepareStLea.executeUpdate();

		DBUtil.closeConnection();
		return result;
	}

	@Override
	public int deleteLawEnforcementAgency(int agencyID)
			throws ClassNotFoundException, SQLException, AgencyNotFoundException {
		lawEnforcementAgencies lea = null;

		connLea = DBUtil.createConnection();

		String queryCheck = "SELECT * FROM lawenforcementagencies WHERE AgencyID = ?";
		String queryDelete = "DELETE FROM lawenforcementagencies WHERE AgencyID = ?";

		String agencyName = null;
		String jurisdiction = null;
		String contactInfo = null;

		int success = 0;

		PreparedStatement prepareStLea = connLea.prepareStatement(queryCheck);
		PreparedStatement prepareStDelete = connLea.prepareStatement(queryDelete);

		prepareStLea.setInt(1, agencyID);
		prepareStDelete.setInt(1, agencyID);

		ResultSet rsLea = prepareStLea.executeQuery();

		while (rsLea.next()) {// Till there are further records.
			agencyID = rsLea.getInt("AgencyID");
			agencyName = rsLea.getString("AgencyName");
			jurisdiction = rsLea.getString("Jurisdiction");
			contactInfo = rsLea.getString("ContactInformation");

			lea = new lawEnforcementAgencies(agencyName, jurisdiction, contactInfo);
		}

		if (lea == null) {
			throw new AgencyNotFoundException("No Agency Found");
		} else {
			success = prepareStDelete.executeUpdate();
		}
		DBUtil.closeConnection();
		return success;
	}

	@Override
	public lawEnforcementAgencies viewLawEnforcementAgency(int agencyID)
			throws ClassNotFoundException, SQLException, AgencyNotFoundException {
		lawEnforcementAgencies lea = null;

		String agencyName = null;
		String jurisdiction = null;
		String contactInfo = null;

		connLea = DBUtil.createConnection();

		String queryCheck = "SELECT * FROM lawenforcementagencies WHERE AgencyID = ?";
		
				
		PreparedStatement prepareStLea = connLea.prepareStatement(queryCheck);
		prepareStLea.setInt(1, agencyID);
		
		ResultSet rsLea = prepareStLea.executeQuery();

		while (rsLea.next()) {// Till there are further records.
			agencyID = rsLea.getInt("AgencyID");
			agencyName = rsLea.getString("AgencyName");
			jurisdiction = rsLea.getString("Jurisdiction");
			contactInfo = rsLea.getString("ContactInformation");
			
			lea = new lawEnforcementAgencies(agencyID, agencyName, jurisdiction, contactInfo);
		}
		DBUtil.closeConnection();

		if (lea == null) {
			throw new AgencyNotFoundException("No Agency Found");
		}

		return lea;
	}

	@Override
	public List<lawEnforcementAgencies> viewLawEnforcementAgencies()
			throws ClassNotFoundException, SQLException, AgencyNotFoundException {
		List<lawEnforcementAgencies> leas = new ArrayList<>();
		
		lawEnforcementAgencies lea = null;

		connLea = DBUtil.createConnection();

		String query = "SELECT * FROM lawenforcementagencies";

		int agencyID = 0;
		String agencyName = null;
		String jurisdiction = null;
		String contactInfo = null;
		
		PreparedStatement prepareStLea = connLea.prepareStatement(query);

		ResultSet rsLea = prepareStLea.executeQuery();

		while (rsLea.next()) {// Till there are further records.
			agencyID = rsLea.getInt("AgencyID");
			agencyName = rsLea.getString("AgencyName");
			jurisdiction = rsLea.getString("Jurisdiction");
			contactInfo = rsLea.getString("ContactInformation");
			
			lea = new lawEnforcementAgencies(agencyID, agencyName, jurisdiction, contactInfo);
			leas.add(lea);
		}
		DBUtil.closeConnection();

		if (leas.size() == 0) {
			throw new AgencyNotFoundException("No agency Found");
		}

		return leas;
	}

	
}
