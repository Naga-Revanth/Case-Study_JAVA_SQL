package com.CrimeAnalysisAndReportingSystem.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.CrimeAnalysisAndReportingSystem.entity.Incidents;
import com.CrimeAnalysisAndReportingSystem.entity.Officers;
import com.CrimeAnalysisAndReportingSystem.entity.Reports;
import com.CrimeAnalysisAndReportingSystem.entity.Suspects;
import com.CrimeAnalysisAndReportingSystem.entity.Victims;
import com.CrimeAnalysisAndReportingSystem.entity.lawEnforcementAgencies;
import com.CrimeAnalysisAndReportingSystem.exception.ReportNotFoundException;
import com.CrimeAnalysisAndReportingSystem.service.CrimeAnalysisServiceImpl;
import com.CrimeAnalysisAndReportingSystem.service.ICrimeAnalysisService;
import com.CrimeAnalysisAndReportingSystem.service.IOfficerService;
import com.CrimeAnalysisAndReportingSystem.service.OfficerServiceImpl;
import com.CrimeAnalysisAndReportingSystem.util.DBUtil;


public class ReportDAOImpl implements IReportDAO {

private static Connection connReport;
	
	@Override
	public int addReport(Reports report) throws ClassNotFoundException, SQLException {
		connReport = DBUtil.createConnection();
		String query = "INSERT INTO Reports(IncidentID, ReportingOfficer, ReportDate, ReportDetails, Status) "
				+ "VALUES( ?, ?, ?, ?, ?)";

		Date reportDate = Date.valueOf(report.getReportDate());

		PreparedStatement prepareStReport = connReport.prepareStatement(query);
		prepareStReport.setInt(1, report.getIncident().getIncidentID());
		prepareStReport.setInt(2, report.getReportingOfficer().getOfficerId());
		prepareStReport.setDate(3, reportDate);
		prepareStReport.setString(4, report.getReportDetails());
		prepareStReport.setString(5, report.getStatus());

		int result = prepareStReport.executeUpdate();

		DBUtil.closeConnection();
		return result;
	}

	@Override
	public int updateReport(Reports report) throws ClassNotFoundException, SQLException, ReportNotFoundException {
		connReport = DBUtil.createConnection();
		String query = "UPDATE Reports SET IncidentID=?, ReportingOfficer=?, ReportDate=?, ReportDetails=?, Status=? "
				+ "WHERE ReportID=?";

		Date reportDate = Date.valueOf(report.getReportDate());

		PreparedStatement prepareStReport = connReport.prepareStatement(query);
		prepareStReport.setInt(1, report.getIncident().getIncidentID());
		prepareStReport.setInt(2, report.getReportingOfficer().getOfficerId());
		prepareStReport.setDate(3, reportDate);
		prepareStReport.setString(4, report.getReportDetails());
		prepareStReport.setString(5, report.getStatus());
		prepareStReport.setInt(6, report.getReportId());
		
		int result = prepareStReport.executeUpdate();

		DBUtil.closeConnection();
		return result;
	}

	@Override
	public int deleteReport(int reportID) throws ClassNotFoundException, SQLException, ReportNotFoundException {
		Reports report = null;

		LocalDate reportDate = null;

		connReport = DBUtil.createConnection();

		String queryCheck = "SELECT * FROM Reports WHERE ReportID = ?";
		String queryDelete = "DELETE FROM Reports WHERE ReportID = ?";

		String reportDetails = null;
		String status = null;

		int success = 0;

		PreparedStatement prepareStReport = connReport.prepareStatement(queryCheck);
		PreparedStatement prepareStDelete = connReport.prepareStatement(queryDelete);

		prepareStReport.setInt(1, reportID);
		prepareStDelete.setInt(1, reportID);

		ResultSet rsReport = prepareStReport.executeQuery();

		while (rsReport.next()) {// Till there are further records.
			reportID = rsReport.getInt("ReportID");
			reportDate = rsReport.getDate("ReportDate").toLocalDate();
			reportDetails = rsReport.getString("ReportDetails");
			status = rsReport.getString("Status");

			report = new Reports(reportDate, reportDetails, status);
		}

		if (report == null) {
			throw new ReportNotFoundException("No Report Found");
		} else {
			success = prepareStDelete.executeUpdate();
		}
		DBUtil.closeConnection();
		return success;
	}

	@Override
	public Reports viewReport(int reportID) throws ClassNotFoundException, SQLException, ReportNotFoundException {
		Incidents incident = null;
		
		int incidentID = 0;
		String incidentType = null;
		LocalDate incDate = null;
		String location = null;
		String description = null;
		String status = null;
		
		Reports report = null;
		
		LocalDate rReportDate = null;
		String rReportDetails = null;
		String rStatus = null;
		
		Officers reportingOfficer = null;
		
		int officerID = 0;

		String oFirstName = null;
		String oLastName = null;
		String oBadgeNumber = null;
		String oRank = null;
		String oContactInfo = null;
		
		lawEnforcementAgencies lea = null;
		int agencyID =0;
		String lAgencyName = null;
		String lJurisdiction = null;
		String lContactInfo = null;
		
		Victims victim = null;
		Suspects suspect = null;
		
//		int victimID = 0;
//		String vFirstName = null;
//		String vLastName = null;
//		LocalDate vDateOfBirth = null;
//		String vGender = null;
//		String vContactInfo = null;
//		
//		int suspectID = 0;
//		String sFirstName = null;
//		String sLastName = null;
//		LocalDate sDateOfBirth = null;
//		String sGender = null;
//		String sContactInfo = null;
		
		connReport = DBUtil.createConnection();

		String queryCheck = "SELECT i.IncidentID,i.IncidentType,i.IncidentDate,i.Location,i.Description,i.Status," 
				+ " r.ReportID, r.IncidentID, r.ReportingOfficer, r.ReportDate, r.ReportDetails, r.Status," 
				+ " o.OfficerID,o.FirstName, o.LastName, o.BadgeNumber,o.Rankp,o.ContactInformation,"
				+ " l.AgencyID, l.AgencyName, l.Jurisdiction ,l.ContactInformation " 
				+ " FROM Incidents i JOIN Reports r "
				+ " ON i.IncidentID = r.IncidentID JOIN Officers o ON r.ReportingOfficer = o.OfficerID " 
				+ " JOIN lawenforcementagencies l ON o.AgencyId = l.AgencyId " 
				+ "WHERE r.ReportID = ?";
		
				
		PreparedStatement prepareStReport = connReport.prepareStatement(queryCheck);
		prepareStReport.setInt(1, reportID);
		
		ResultSet rsReport = prepareStReport.executeQuery();

		while (rsReport.next()) {// Till there are further records.
			incidentID = rsReport.getInt("i.IncidentID");
			incidentType = rsReport.getString("i.IncidentType");
			incDate = rsReport.getDate("i.IncidentDate").toLocalDate();
			location = rsReport.getString("i.Location");
			description = rsReport.getString("i.Description");
			status = rsReport.getString("i.Status");
			
//			victimID = rsReport.getInt("i.VictimID");
//			vFirstName = rsReport.getString("v.FirstName");
//			vLastName = rsReport.getString("v.LastName");
//			vDateOfBirth = rsReport.getDate("v.DateOfBirth").toLocalDate();
//			vGender = rsReport.getString("v.Gender");
//			vContactInfo = rsReport.getString("v.ContactInformation");
//			
//			suspectID = rsReport.getInt("s.SuspectID");
//			sFirstName = rsReport.getString("s.FirstName");
//			sLastName = rsReport.getString("s.LastName");
//			sDateOfBirth = rsReport.getDate("s.DateOfBirth").toLocalDate();
//			sGender = rsReport.getString("s.Gender");
//			sContactInfo = rsReport.getString("s.ContactInformation");
//			
//			victim = new Victims(victimID, vFirstName, vLastName, vDateOfBirth, vGender, vContactInfo);
//			
//			suspect = new Suspects(suspectID, sFirstName, sLastName, sDateOfBirth, sGender, sContactInfo);			
			
			agencyID = rsReport.getInt("l.AgencyID");
			lAgencyName = rsReport.getString("l.AgencyName");
			lJurisdiction = rsReport.getString("l.Jurisdiction");
			lContactInfo = rsReport.getString("l.ContactInformation");
			
			reportID = rsReport.getInt("r.ReportID");
			rReportDate = rsReport.getDate("r.ReportDate").toLocalDate();
			rReportDetails = rsReport.getString("r.ReportDetails");
			rStatus = rsReport.getString("r.Status");
			
			officerID = rsReport.getInt("o.OfficerID");
			oFirstName = rsReport.getString("o.FirstName");
			oLastName = rsReport.getString("o.LastName");
			oBadgeNumber = rsReport.getString("o.BadgeNumber");
			oRank = rsReport.getString("o.Rankp");
			oContactInfo = rsReport.getString("o.ContactInformation");
			
			lea = new lawEnforcementAgencies(agencyID, lAgencyName, lJurisdiction, lContactInfo);
			reportingOfficer = new Officers(officerID, oFirstName, oLastName, oBadgeNumber, oRank, oContactInfo, lea);
			incident = new Incidents(incidentID, incidentType, incDate, location, description, status, victim, suspect);
			report = new Reports(reportID, incident, reportingOfficer, rReportDate, rReportDetails, rStatus);
		}
		DBUtil.closeConnection();

		if (report == null) {
			throw new ReportNotFoundException("No report Found");
		}

		return report;
	}

	@Override
	public List<Reports> viewReports() throws ClassNotFoundException, SQLException, ReportNotFoundException {
		ICrimeAnalysisService incidentService = new CrimeAnalysisServiceImpl();
		IOfficerService officerService = new OfficerServiceImpl();
		List<Reports> reports = new ArrayList<>();
		Reports report = null;

		LocalDate rReportDate = null;
		String rReportDetails = null;
		String rStatus = null;
		
		Incidents incident = null;
		Officers reportingOfficer = null;

		connReport = DBUtil.createConnection();

		String query = "SELECT * FROM Reports";

		int incidentID = 0;
		int reportID = 0;
		int officerID = 0;
		
		PreparedStatement prepareStIncident = connReport.prepareStatement(query);

		ResultSet rsIncident = prepareStIncident.executeQuery();

		while (rsIncident.next()) {// Till there are further records.
			reportID = rsIncident.getInt("ReportID");
			officerID = rsIncident.getInt("ReportingOfficer");
			incidentID = rsIncident.getInt("IncidentID");
			rReportDate = rsIncident.getDate("ReportDate").toLocalDate();
			rReportDetails = rsIncident.getString("ReportDetails");
			rStatus = rsIncident.getString("Status");
			incident = incidentService.viewIncident(incidentID);
			reportingOfficer = officerService.viewOfficer(officerID);
			
			report = new Reports(reportID, incident, reportingOfficer, rReportDate, rReportDetails, rStatus);
			reports.add(report);
		}
		DBUtil.closeConnection();

		if (reports.size() == 0) {
			throw new ReportNotFoundException("No report Found");
		}

		return reports;
	}


}
