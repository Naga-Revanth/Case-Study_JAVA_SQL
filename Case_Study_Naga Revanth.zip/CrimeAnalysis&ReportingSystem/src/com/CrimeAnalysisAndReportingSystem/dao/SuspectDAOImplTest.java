package com.CrimeAnalysisAndReportingSystem.dao;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.CrimeAnalysisAndReportingSystem.entity.Suspects;
import com.CrimeAnalysisAndReportingSystem.exception.SuspectNotFoundException;


public class SuspectDAOImplTest {
	private ISuspectDAO suspectDAO;

	@Before
	public void setUp() throws Exception {
		suspectDAO = new SuspectDAOImpl();
	}

	@After
	public void tearDown() throws Exception {
		suspectDAO = null;
	}

	@Test
	public final void testAddSuspect() {
		int result = 0;
		LocalDate date = LocalDate.of(2001, 11, 27);
		Suspects suspect = new Suspects(5, "Ram", "Kumar", date, "male", "7904987921");
		try {
			result = suspectDAO.addSuspect(suspect);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		}
		assertTrue(result == 1);
	}

	@Test
	public final void testUpdateSuspect() {
		int result = 0;
		LocalDate date = LocalDate.of(2001, 11, 27);
		Suspects suspect = new Suspects(5, "Ram", "Kumar", date, "male", "7904987921");
		try {
			result = suspectDAO.updateSuspect(suspect);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		}catch(SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		}catch(SuspectNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}
		assertTrue(result == 1);
	}

	@Test
	public final void testDeleteSuspect() {
		int result = 0;
		int suspectID = 3;
		try {
			result = suspectDAO.deleteSuspect(suspectID);
			}catch (ClassNotFoundException cnfe) {
				System.out.println("Looks like JDBC driver is NOT loaded.");
			}catch(SQLException se) {
				System.out.println("Either url, username or password is wrong or duplicate record");
				se.printStackTrace();
			}catch(SuspectNotFoundException cnfe) {
				System.out.println(cnfe.getMessage());
			}
		
		assertTrue(result == 1);
	}

	@Test
	public final void testViewSuspect() {
		Suspects suspect = null;
		int suspectID = 1;
		try {
			suspect = suspectDAO.viewSuspect(suspectID);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (SuspectNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}
		assertTrue(suspect != null);
	}

	@Test
	public final void testViewSuspects() {
		List<Suspects> suspectList = null;

		try {
			suspectList = suspectDAO.viewSuspects();
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (SuspectNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}
		assertTrue(suspectList != null);
	}

}
