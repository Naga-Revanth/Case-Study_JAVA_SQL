package com.CrimeAnalysisAndReportingSystem.dao;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.CrimeAnalysisAndReportingSystem.entity.Victims;
import com.CrimeAnalysisAndReportingSystem.exception.VictimNotFoundException;


public class VictimDAOImplTest {
	private IVictimDAO victimDAO;

	@Before
	public void setUp() throws Exception {
		victimDAO = new VictimDAOImpl();
	}

	@After
	public void tearDown() throws Exception {
		victimDAO = null;
	}

	@Test
	public final void testAddVictim() {
		int result = 0;
		LocalDate date = LocalDate.of(2001, 01, 07);
		Victims victim = new Victims("Ashok", "Kumar", date, "male", "7904467348");
		try {
			result = victimDAO.addVictim(victim);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		}
		assertTrue(result == 1);
	}

	@Test
	public final void testUpdateVictim() {
		int result = 0;
		LocalDate date = LocalDate.of(2002, 05, 23);
		Victims victim = new Victims( 2,"Vijay", "Kumar", date, "male", "7998670123");
		try {
			result = victimDAO.updateVictim(victim);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		} catch (VictimNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}
		assertTrue(result == 1);
	}

	@Test
	public final void testDeleteVictim() {
		int result = 0;
		int victimID = 3;
		try {
			result = victimDAO.deleteVictim(victimID);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		} catch (VictimNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}

		assertTrue(result == 1);
	}

	@Test
	public final void testViewVictim() {
		Victims victim = null;
		int victimID = 1;

		try {
			victim = victimDAO.viewVictim(victimID);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (VictimNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}

		assertTrue(victim != null);
	}

	@Test
	public final void testViewVictims() {
		List<Victims> victimList = null;

		try {
			victimList = victimDAO.viewVictims();
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (VictimNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}
		assertTrue(victimList != null);
	}

}
