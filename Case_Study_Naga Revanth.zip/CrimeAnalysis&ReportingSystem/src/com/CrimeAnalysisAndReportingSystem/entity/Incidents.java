package com.CrimeAnalysisAndReportingSystem.entity;

import java.time.LocalDate;
import java.util.Objects;



public class Incidents {
	private int incidentID;// (Primary Key)
	private String incidentType;// (e.g., Robbery, Homicide, Theft)
	private LocalDate incidentDate;
	private String location;
	private String description;
	private String status;// (e.g., Open, Closed, Under Investigation)
	private Victims victim;// (Foreign Key, linking to Victims)
	private Suspects suspect;// (Foreign Key, Linking to Suspect)

	public Incidents() {
		super();
	}

	public Incidents(int incidentID, String incidentType, LocalDate incidentDate, String location, String description,
			String status) {
		super();
		this.incidentID = incidentID;
		this.incidentType = incidentType;
		this.incidentDate = incidentDate;
		this.location = location;
		this.description = description;
		this.status = status;
	}

	public Incidents(String incidentType, LocalDate incidentDate, String location, String description, String status) {
		super();
		this.incidentType = incidentType;
		this.incidentDate = incidentDate;
		this.location = location;
		this.description = description;
		this.status = status;
	}

	public Incidents(String incidentType, LocalDate incidentDate, String location, String description, String status,
			Victims victim, Suspects suspect) {
		super();
		this.incidentType = incidentType;
		this.incidentDate = incidentDate;
		this.location = location;
		this.description = description;
		this.status = status;
		this.victim = victim;
		this.suspect = suspect;
	}

	public Incidents(int incidentID, String incidentType, LocalDate incidentDate, String location, String description,
			String status, Victims victim, Suspects suspect) {
		super();
		this.incidentID = incidentID;
		this.incidentType = incidentType;
		this.incidentDate = incidentDate;
		this.location = location;
		this.description = description;
		this.status = status;
		this.victim = victim;
		this.suspect = suspect;
	}

	public int getIncidentID() {
		return incidentID;
	}

	public void setIncidentID(int incidentID) {
		this.incidentID = incidentID;
	}

	public String getIncidentType() {
		return incidentType;
	}

	public void setIncidentType(String incidentType) {
		this.incidentType = incidentType;
	}

	public LocalDate getIncidentDate() {
		return incidentDate;
	}

	public void setIncidentDate(LocalDate incidentDate) {
		this.incidentDate = incidentDate;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Victims getVictim() {
		return victim;
	}

	public void setVictim(Victims victim) {
		this.victim = victim;
	}

	public Suspects getSuspect() {
		return suspect;
	}

	public void setSuspect(Suspects suspect) {
		this.suspect = suspect;
	}

	@Override
	public int hashCode() {
		return Objects.hash(description, incidentDate, incidentID, incidentType, location, status, suspect, victim);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Incidents other = (Incidents) obj;
		return Objects.equals(description, other.description) && Objects.equals(incidentDate, other.incidentDate)
				&& incidentID == other.incidentID && Objects.equals(incidentType, other.incidentType)
				&& Objects.equals(location, other.location) && Objects.equals(status, other.status)
				&& Objects.equals(suspect, other.suspect) && Objects.equals(victim, other.victim);
	}

	@Override
	public String toString() {
		return "Incidents [incidentID=" + incidentID + ", incidentType=" + incidentType + ", incidentDate="
				+ incidentDate + ", location=" + location + ", description=" + description + ", status=" + status
				+ ", victim=" + victim + ", suspect=" + suspect + "]";
	}


}