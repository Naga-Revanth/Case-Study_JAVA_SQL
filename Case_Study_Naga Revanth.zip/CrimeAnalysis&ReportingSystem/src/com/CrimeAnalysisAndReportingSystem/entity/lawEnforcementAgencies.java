package com.CrimeAnalysisAndReportingSystem.entity;

import java.util.Objects;

public class lawEnforcementAgencies {
	 private int  agencyId;
     private String agencyName;
     private String jurisdiction;
     private String phoneNumber;
	@Override
	public int hashCode() {
		return Objects.hash(agencyId, agencyName, jurisdiction, phoneNumber);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		lawEnforcementAgencies other = (lawEnforcementAgencies) obj;
		return agencyId == other.agencyId && Objects.equals(agencyName, other.agencyName)
				&& Objects.equals(jurisdiction, other.jurisdiction) && Objects.equals(phoneNumber, other.phoneNumber);
	}
	@Override
	public String toString() {
		return "lawEnforcementAgencies [agencyId=" + agencyId + ", agencyName=" + agencyName + ", jurisdiction="
				+ jurisdiction + ", phoneNumber=" + phoneNumber + "]";
	}
	public lawEnforcementAgencies() {
		super();
		// TODO Auto-generated constructor stub
	}
	public lawEnforcementAgencies(int agencyId, String agencyName, String jurisdiction, String phoneNumber) {
		super();
		this.agencyId = agencyId;
		this.agencyName = agencyName;
		this.jurisdiction = jurisdiction;
		this.phoneNumber = phoneNumber;
	}
	public int getAgencyId() {
		return agencyId;
	}
	public void setAgencyId(int agencyId) {
		this.agencyId = agencyId;
	}
	public String getAgencyName() {
		return agencyName;
	}
	public void setAgencyName(String agencyName) {
		this.agencyName = agencyName;
	}
	public String getJurisdiction() {
		return jurisdiction;
	}
	public void setJurisdiction(String jurisdiction) {
		this.jurisdiction = jurisdiction;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public lawEnforcementAgencies(String agencyName, String jurisdiction, String phoneNumber) {
		super();
		this.agencyName = agencyName;
		this.jurisdiction = jurisdiction;
		this.phoneNumber = phoneNumber;
	}
     
     
	    
}