package com.CrimeAnalysisAndReportingSystem.exception;

public class ReportNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ReportNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ReportNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
