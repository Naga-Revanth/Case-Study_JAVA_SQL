package com.CrimeAnalysisAndReportingSystem.service;

import java.util.List;

import com.CrimeAnalysisAndReportingSystem.entity.lawEnforcementAgencies;

public interface ILawEnforcementAgenciesService {
	public int addLawEnforcementAgency(lawEnforcementAgencies lea);
	public int updateLawEnforcementAgency(lawEnforcementAgencies lea);
	public int deleteLawEnforcementAgency(int agencyID);
	public lawEnforcementAgencies viewLawEnforcementAgency(int agencyID);
	public List<lawEnforcementAgencies>viewLawEnforcementAgencies();

}
