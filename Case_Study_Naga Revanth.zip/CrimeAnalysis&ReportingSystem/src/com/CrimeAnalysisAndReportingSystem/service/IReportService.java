package com.CrimeAnalysisAndReportingSystem.service;

import java.util.List;

import com.CrimeAnalysisAndReportingSystem.entity.Reports;

public interface IReportService {

	public int addReport(Reports report);
	public int updateReport(Reports report);
	public int deleteReport(int reportID);
	public Reports viewReport(int reportID);
	public List<Reports>viewReports();
	
}
