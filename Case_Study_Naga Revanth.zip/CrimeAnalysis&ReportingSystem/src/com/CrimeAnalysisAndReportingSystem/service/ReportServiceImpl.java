package com.CrimeAnalysisAndReportingSystem.service;

import java.sql.SQLException;
import java.util.List;

import com.CrimeAnalysisAndReportingSystem.dao.IReportDAO;
import com.CrimeAnalysisAndReportingSystem.dao.ReportDAOImpl;
import com.CrimeAnalysisAndReportingSystem.entity.Reports;
import com.CrimeAnalysisAndReportingSystem.exception.ReportNotFoundException;

public class ReportServiceImpl implements IReportService {


	private IReportDAO reportDAO;

	public ReportServiceImpl() {
		this.reportDAO = new ReportDAOImpl();
	}
	
	@Override
	public int addReport(Reports report) {
		int result = 0;
		try {
			result = reportDAO.addReport(report);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		}
		return result;
	}

	@Override
	public int updateReport(Reports report) {
		int result = 0;
		try {
			result = reportDAO.updateReport(report);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		}catch(SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		}catch(ReportNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}
		return result;
	}

	@Override
	public int deleteReport(int reportID) {
		int result = 0;
		try {
			result = reportDAO.deleteReport(reportID);
			}catch (ClassNotFoundException cnfe) {
				System.out.println("Looks like JDBC driver is NOT loaded.");
			}catch(SQLException se) {
				System.out.println("Either url, username or password is wrong or duplicate record");
				se.printStackTrace();
			}catch(ReportNotFoundException cnfe) {
				System.out.println(cnfe.getMessage());
			}
		
		return result;
	}

	@Override
	public Reports viewReport(int reportID) {
		Reports report = null;

		try {
			report = reportDAO.viewReport(reportID);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		} catch (ReportNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}

		return report;
	}

	@Override
	public List<Reports> viewReports() {
		List<Reports> reportList = null;

		try {
			reportList = reportDAO.viewReports();
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (ReportNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}
		return reportList;
	}


}
